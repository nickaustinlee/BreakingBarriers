VERSION = '0.1'

from cosmSender import *

